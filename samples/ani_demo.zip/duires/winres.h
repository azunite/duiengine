#pragma once


/*<---------------------------RES_BUILDER:begin-----------------------------------*/
#define	maindlg		65537
#define	btn_close		1
#define	img_tst		65539
#define	btn_ani		65540
#define	ani_slide		65541
#define	ani_center		65542
#define	ani_blend		65543
#define	grp_animode		65544
#define	grp_slide_mode		65545
#define	slide_hor_nagetive		65546
#define	slide_hor_positive		65547
#define	slide_ver_nagetive		65548
#define	slide_ver_positive		65549
#define	grp_hor_mode		65550
#define	grp_ver_mode		65551
/*----------------------------RES_BUILDER:end------------------------------------->*/

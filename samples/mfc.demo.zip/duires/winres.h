#pragma once


/*<---------------------------RES_BUILDER:begin-----------------------------------*/
#define	maindlg		65537
#define	close		1
#define	btn_msgbox		65538
#define	mfcbtn		65539
/*----------------------------RES_BUILDER:end------------------------------------->*/

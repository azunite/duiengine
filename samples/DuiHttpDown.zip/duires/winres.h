#pragma once


/*<---------------------------RES_BUILDER:begin-----------------------------------*/
#define	maindlg		65537
#define	btn_close		1
#define	ani_install		65538
#define	prog_down		65539
#define	btn_down		65540
#define	edit_url		65541
#define	edit_to		65542
/*----------------------------RES_BUILDER:end------------------------------------->*/

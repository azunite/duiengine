/********************************************************************
created:	2010/01/11
created:	11:1:2010   11:59
file base:	HttpAsynDownImp
file ext:	h
author:		QuickBasic
	
purpose:	http�첽����ʵ��
*********************************************************************/
#pragma once
#include "RefCount.h"
#include "Winhttp.h"
#pragma  comment(lib,"winhttp.lib")
#include "HttpCallBackImp.h"

enum E_TRAN_TYPE{TRAN_TRUNK,TRAN_LENGTH};

interface IHttpCallback
{
	virtual bool IsAsync()=NULL;
	virtual void OnStart(E_TRAN_TYPE eType,DWORD length)=NULL;
	virtual void OnRequestProgress(ULONG ulProgress,ULONG ulProgressMax)=NULL;
	virtual void OnResponseProgress(ULONG ulProgress,ULONG ulProgressMax)=NULL;
	virtual void OnNotify(DWORD dwErr,DWORD dwInfo)=NULL;
	virtual void OnAbort()=NULL;
	virtual void OnFinished(PCHAR ResponseText,DWORD dwSize)=NULL;
	virtual void OnCloseConnect()=NULL;
};

//----------------------------------------------------------------------------------------------------------
template<class T>
class CHttpDownload : public T
	, public RefCountedThreadSafe<CHttpDownload<T>>
{
	friend class RefCountedThreadSafe<CHttpDownload<T>>;
private:
	IHttpCallback *	pHttpCallback;
	HINTERNET	hSession;		//�Ự
	HINTERNET   hConnect;       // ����
	HINTERNET   hRequest;       // ����
	HANDLE		hFile;			//�����ļ�

	DWORD dwFileCurSize;
	DWORD dwFileTotalSize;

	DWORD dwLastBlockSize;
	BYTE *lpLastBlockRecvBuffer;
	
private:
	void CloseHandle()
	{
		if( hRequest ) WinHttpCloseHandle( hRequest );
		if( hConnect ) WinHttpCloseHandle( hConnect );
		if( hSession ) WinHttpCloseHandle( hSession );
		hRequest=hConnect=hSession=NULL;
	}
	
protected:
	CHttpDownload()
		:dwFileCurSize(0)
		,dwFileTotalSize(0)
		,dwLastBlockSize(0)
		,lpLastBlockRecvBuffer(NULL)
		,hFile(INVALID_HANDLE_VALUE)
	{
		pHttpCallback = static_cast<IHttpCallback*>(this);//��֤ģ�����T�Ǵ�IHttpCallback����
	}

	virtual ~CHttpDownload()
	{
		WinHttpCloseHandle(hSession);
		CloseFile();	//�ر��ļ�
		if(lpLastBlockRecvBuffer!=NULL)
		{
			DWORD dwNumberOfBytesWritten = 0;
			delete [](lpLastBlockRecvBuffer);
			lpLastBlockRecvBuffer = NULL;
		}		 
	}

public:
	static CHttpDownload<T> * CreateInstance()
	{
		//�ڶ��Ϸ��䣬��֤����ʹ��Release�ͷš�
		return new CHttpDownload<T>;
	}

	VOID CloseFile()
	{
		if(hFile != INVALID_HANDLE_VALUE)
		{
			::CloseHandle(hFile);
			hFile = INVALID_HANDLE_VALUE;
		}
	}

	BOOL Download(LPCWSTR pszRemote,LPCWSTR pszLocal)
	{
		WCHAR szHost[256];
		AddRef();
		if(!pHttpCallback)
		{
			Release();
			return FALSE;
		}

		hSession = WinHttpOpen( L"Mozilla/4.0 (compatible; MSIE 6.0; Windows 2000)", 
			WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
			WINHTTP_NO_PROXY_NAME,
			WINHTTP_NO_PROXY_BYPASS,
			pHttpCallback->IsAsync()?WINHTTP_FLAG_ASYNC:0 );

		if(!hSession)
		{
			Release();
			return FALSE;
		}

		URL_COMPONENTS urlComp;
		ZeroMemory( &urlComp, sizeof(urlComp) );
		urlComp.dwStructSize = sizeof(urlComp);

		urlComp.lpszHostName      = szHost;
		urlComp.dwHostNameLength  = sizeof(szHost) / sizeof(szHost[0]);
		urlComp.dwUrlPathLength = -1;
		urlComp.dwSchemeLength  = -1;     
		if( !WinHttpCrackUrl( pszRemote, 0, 0, &urlComp ) )
		{
			Stop();
			Release();
			return FALSE;
		}
		DWORD dwOpenRequestFlag =( INTERNET_SCHEME_HTTPS == urlComp.nScheme)? WINHTTP_FLAG_SECURE : 0;

		hFile = CreateFile(pszLocal,    
							GENERIC_WRITE,
							0,
							NULL,
							CREATE_ALWAYS,
							FILE_ATTRIBUTE_NORMAL,
							NULL);

		if (hFile == INVALID_HANDLE_VALUE) 
		{
			pHttpCallback->OnNotify(0,0);
			Stop();
			Release();
			return FALSE;
		}

		hConnect = WinHttpConnect( hSession, szHost, urlComp.nPort, 0 ) ;
		hRequest = WinHttpOpenRequest( hConnect, 
			L"GET", urlComp.lpszUrlPath,
			L"HTTP/1.1", WINHTTP_NO_REFERER, 
			WINHTTP_DEFAULT_ACCEPT_TYPES,
			dwOpenRequestFlag );
		if(hRequest==NULL)
		{
			pHttpCallback->OnNotify(0,0);
			Stop();
			Release();
			return FALSE;
		}

		WinHttpAddRequestHeaders( hRequest, 
									L"Accept: text/html,  */*;q=1",
									-1,
									WINHTTP_ADDREQ_FLAG_ADD );

		WinHttpAddRequestHeaders( hRequest, 
									L"Accept-Language: zh-CN;q=1.0",
									-1,
									WINHTTP_ADDREQ_FLAG_ADD );
		WinHttpAddRequestHeaders( hRequest, 
									L"Accept-Charset: *;q=1.2",
									-1,
									WINHTTP_ADDREQ_FLAG_ADD );
		WinHttpAddRequestHeaders( hRequest, 
			L"Accept-Encoding: deflate,*",
			-1,
			WINHTTP_ADDREQ_FLAG_ADD );
			


		if(pHttpCallback->IsAsync())
		{//�첽����

			WINHTTP_STATUS_CALLBACK prevCallback = WinHttpSetStatusCallback(
				hRequest,
				(WINHTTP_STATUS_CALLBACK) CallbackProc,
				WINHTTP_CALLBACK_FLAG_ALL_COMPLETIONS |
				WINHTTP_CALLBACK_FLAG_HANDLES|
				WINHTTP_CALLBACK_FLAG_REDIRECT,
				NULL );

			if(prevCallback == WINHTTP_INVALID_STATUS_CALLBACK)
			{
				pHttpCallback->OnNotify(0,0);
				Stop();
				Release();
				return FALSE;
			}

			if( !WinHttpSendRequest( hRequest, 
				WINHTTP_NO_ADDITIONAL_HEADERS, 0, 
				WINHTTP_NO_REQUEST_DATA, 0, 0, 
				(DWORD_PTR)this))
			{
				//�����ڲ�����������Ҳ����ͨ���̵߳��ص�����������Ҫ�ֶ�����
				pHttpCallback->OnNotify(0,0);
				Stop();
				this->Release();
				return FALSE;
			}
			return TRUE;
		}else
		{//ͬ������
			if( !WinHttpSendRequest( hRequest, 	WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, (DWORD_PTR)this))
				goto DL_ERR;
			CallbackProc(hRequest,(DWORD_PTR)this,WINHTTP_CALLBACK_STATUS_SENDREQUEST_COMPLETE,NULL,0);//��������
			if(!hRequest) goto DL_ERR;
			CallbackProc(hRequest,(DWORD_PTR)this,WINHTTP_CALLBACK_STATUS_HEADERS_AVAILABLE,NULL,0);//��ѯ�ļ���Ϣ
			if(!hRequest) goto DL_ERR;
			//��ʼ��������
			while(dwLastBlockSize!=0)
			{
				CallbackProc(hRequest,(DWORD_PTR)this,WINHTTP_CALLBACK_STATUS_DATA_AVAILABLE,&dwLastBlockSize,sizeof(DWORD));//��ѯ�ɶ�����
				if(!hRequest) goto DL_ERR;
				CallbackProc(hRequest,(DWORD_PTR)this,WINHTTP_CALLBACK_STATUS_READ_COMPLETE,lpLastBlockRecvBuffer,dwLastBlockSize);//д�ļ�
				if(!hRequest) goto DL_ERR;
			}
			CallbackProc(hRequest,(DWORD_PTR)this,WINHTTP_CALLBACK_STATUS_DATA_AVAILABLE,&dwLastBlockSize,sizeof(DWORD));//���ؽ���
			this->Release();
			return TRUE;
DL_ERR:
			this->Release();
			return FALSE;
		}
	}

	BOOL Stop()
	{
		CloseHandle();
		return TRUE;
	}

private:
	// WinHttp �ļ������첽����ص�����
	static VOID CALLBACK	CallbackProc( IN HINTERNET hInternet, 
											IN DWORD_PTR dwContext, 
											IN DWORD dwInternetStatus, 
											IN LPVOID lpvStatusInformation OPTIONAL, 
											IN DWORD dwStatusInformationLength )
	{
		CHttpDownload *pThis = (CHttpDownload *)dwContext;
		pThis->AddRef();
		switch (dwInternetStatus)
		{
			//���������
		case WINHTTP_CALLBACK_STATUS_SENDREQUEST_COMPLETE:
			{
				if (WinHttpReceiveResponse( pThis->hRequest, NULL) == FALSE)
				{
					pThis->CloseHandle();
					pThis->pHttpCallback->OnNotify(0,0);
				}
			}break;
		case WINHTTP_CALLBACK_STATUS_HEADERS_AVAILABLE:
			{
				//����ļ�����
				DWORD dwSize=sizeof(DWORD);
				DWORD StatusCode = 0;
				BOOL bRet = FALSE;
				bRet = WinHttpQueryHeaders( pThis->hRequest, WINHTTP_QUERY_CONTENT_LENGTH| WINHTTP_QUERY_FLAG_NUMBER ,
					WINHTTP_HEADER_NAME_BY_INDEX, &pThis->dwFileTotalSize, &dwSize, WINHTTP_NO_HEADER_INDEX);

				bRet = WinHttpQueryHeaders( pThis->hRequest, WINHTTP_QUERY_CONTENT_TRANSFER_ENCODING ,
					WINHTTP_HEADER_NAME_BY_INDEX, NULL, &dwSize, WINHTTP_NO_HEADER_INDEX);

			
				DWORD dwLen = 0;
 				WinHttpQueryHeaders( pThis->hRequest, WINHTTP_QUERY_RAW_HEADERS_CRLF,
 					WINHTTP_HEADER_NAME_BY_INDEX, NULL, 
 					&dwLen, WINHTTP_NO_HEADER_INDEX);
 				
 				WCHAR *lpOutBuffer;
 				// Allocate memory for the buffer.
 				if( GetLastError( ) == ERROR_INSUFFICIENT_BUFFER )
 				{
 					lpOutBuffer = new WCHAR[dwLen/sizeof(WCHAR)];
 
 					// Now, use WinHttpQueryHeaders to retrieve the header.
 					WinHttpQueryHeaders( pThis->hRequest, 
 						WINHTTP_QUERY_RAW_HEADERS_CRLF,
 						WINHTTP_HEADER_NAME_BY_INDEX, 
 						lpOutBuffer, &dwLen, 
 						WINHTTP_NO_HEADER_INDEX);
 					delete []lpOutBuffer;
 				}

				bRet = WinHttpQueryHeaders( pThis->hRequest, WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER  ,
					WINHTTP_HEADER_NAME_BY_INDEX, &StatusCode, &dwSize, WINHTTP_NO_HEADER_INDEX);

				if(bRet==FALSE||StatusCode!=HTTP_STATUS_OK )
				{
					pThis->CloseHandle();
					pThis->pHttpCallback->OnNotify(0,0);
				}
				else
				{
					DWORD * pRemain=NULL;
					if(!pThis->pHttpCallback->IsAsync()) pRemain=&pThis->dwLastBlockSize;

					if(WinHttpQueryDataAvailable(pThis->hRequest, pRemain) == FALSE)
					{
						pThis->CloseHandle();
						pThis->pHttpCallback->OnNotify(0,0);
					}
				}
			}break;

		case WINHTTP_CALLBACK_STATUS_DATA_AVAILABLE:
			{
				pThis->dwLastBlockSize = *((LPDWORD)lpvStatusInformation);
				if (pThis->dwLastBlockSize == 0)	//���
				{
					pThis->CloseFile();	//�ر��ļ�
					pThis->pHttpCallback->OnFinished(NULL,0);
					pThis->CloseHandle();
				}else
				{
					//������
					pThis->lpLastBlockRecvBuffer = new BYTE[pThis->dwLastBlockSize];
					ZeroMemory(pThis->lpLastBlockRecvBuffer, pThis->dwLastBlockSize);
					if(WinHttpReadData( pThis->hRequest, (LPVOID)pThis->lpLastBlockRecvBuffer, 
						pThis->dwLastBlockSize, NULL) == FALSE)
					{
						pThis->CloseHandle();
						pThis->pHttpCallback->OnNotify(0,0);
					}
				}


			}break;

		case WINHTTP_CALLBACK_STATUS_READ_COMPLETE:
			{
				if (dwStatusInformationLength != 0)
				{

					if(pThis->lpLastBlockRecvBuffer!=NULL)
					{
						DWORD dwNumberOfBytesWritten = 0;
						WriteFile(pThis->hFile,pThis->lpLastBlockRecvBuffer,pThis->dwLastBlockSize,&dwNumberOfBytesWritten,NULL);
						delete [](pThis->lpLastBlockRecvBuffer);
						pThis->lpLastBlockRecvBuffer = NULL;
					}

					pThis->dwFileCurSize += dwStatusInformationLength;
					pThis->pHttpCallback->OnResponseProgress(pThis->dwFileCurSize,pThis->dwFileTotalSize);
					//���ؿ���
					DWORD *pRemain=NULL;
					if(!pThis->pHttpCallback->IsAsync()) pRemain=&pThis->dwLastBlockSize;
					if(WinHttpQueryDataAvailable(pThis->hRequest, pRemain) == FALSE)							 //������
					{
						pThis->CloseHandle();
						pThis->pHttpCallback->OnNotify(0,0);
					}
				}
			}break;

		case WINHTTP_CALLBACK_STATUS_REDIRECT:
			{
			}break;
		case WINHTTP_CALLBACK_STATUS_REQUEST_ERROR:
			{
				WINHTTP_ASYNC_RESULT *pv = (WINHTTP_ASYNC_RESULT *)lpvStatusInformation;
				pThis->pHttpCallback->OnNotify(0,0);
				pThis->CloseHandle();
			}
			break;
		case WINHTTP_CALLBACK_STATUS_HANDLE_CLOSING :
			{
				pThis->pHttpCallback->OnCloseConnect();
				pThis->Release();
			}
			break;
		default:
			break;
		}
		pThis->Release();
	}
};
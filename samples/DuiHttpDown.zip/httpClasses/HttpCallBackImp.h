/********************************************************************
created:	2013/07/05
file base:	HttpCallBackImp
file ext:	h
author:		Hjx
*********************************************************************/
#pragma once

#include "HttpDownload.h"

typedef struct _MSGDATA
{
	WPARAM wParam;
	LPARAM lParam;
}MSGDATA, * PMSGDATA;


enum MSG_ASYNC{
	HTTP_ASYNC_START = WM_USER + 1000,
	HTTP_ASYNC_REQUEST_PROCESS,	//�����ͽ���
	HTTP_ASYNC_RESPONSE_PROCESS,	//���Խ��ս���
	HTTP_ASYNC_ABORT,				//�û���ֹ
	HTTP_ASYNC_NOTIFY,			//֪ͨ������ǳ�����Ϣ
	HTTP_ASYNC_FINISHED,			//�������� 
	HTTP_ASYNC_CLOSECONNECT		//�Ͽ�����
};

enum MSG_SYNC{
 	HTTP_SYNC_START = WM_USER + 1010,
 	HTTP_SYNC_REQUEST_PROCESS,	//�����ͽ���
 	HTTP_SYNC_RESPONSE_PROCESS,	//���Խ��ս���
 	HTTP_SYNC_ABORT,				//�û���ֹ
 	HTTP_SYNC_NOTIFY,			//֪ͨ������ǳ�����Ϣ
 	HTTP_SYNC_FINISHED,			//�������� 
 	HTTP_SYNC_CLOSECONNECT		//�Ͽ�����
};

//////////////////////////////////////////////////////////////////////////////////
// ����HTTP��Ϣ������

#ifndef SAFEDELETE
#define SAFEDELETE(T) if(T!=NULL){delete T;T=NULL;}
#endif


// RESULT OnHttp_XXX(WPARAM,LPARAM,DWORD)
#define MSG_HTTP_ASYNC_HANDLER(msg,func)                                    \
	if(uMsg == msg)\
	{ \
		SetMsgHandled(TRUE); \
		PMSGDATA pMsgData = (PMSGDATA)lParam; \
		if(NULL != pMsgData)\
			lResult = func(pMsgData->wParam, pMsgData->lParam,(DWORD)wParam); \
		else \
			lResult = func(0,0,0);\
		if(IsMsgHandled()) \
		{ \
			if (NULL != pMsgData) \
				SAFEDELETE(pMsgData); \
			return TRUE; \
		} \
	}

// �ú��������hwnd��Ϣӳ�����
#define MSG_HTTP_ASYNC_DEFAULT()                                    \
	if (HTTP_ASYNC_START <= uMsg && uMsg <= HTTP_ASYNC_CLOSECONNECT)\
	{ \
		PMSGDATA pMsgData = (PMSGDATA)lParam; \
		if (NULL != pMsgData) \
		{ \
		SAFEDELETE(pMsgData);	\
		} \
		return TRUE; \
	}

//ͬ�����ص���Ϣ����
#define MSG_HTTP_SYNC_HANDLER(msg,func)                                    \
	if(uMsg == msg)\
	{ \
		SetMsgHandled(TRUE); \
		PMSGDATA pMsgData = (PMSGDATA)lParam; \
		if(NULL != pMsgData)\
			lResult = func(pMsgData->wParam, pMsgData->lParam,(DWORD)wParam); \
		else \
			lResult=func(0,0,0);\
		return lResult;\
	}

//ͬ�����صĴ�����Ϣ�ص�
class WinMsgQueueSync : public IHttpCallback
{
public:
	void InitCallback(HWND hWnd,DWORD dwID)
	{
		m_hWnd=hWnd;
		m_dwData=dwID;
	}

protected:
	BOOL SendMessage(__in UINT Msg,__in WPARAM wParam,__in LPARAM lParam)
	{
		if(IsWindow(m_hWnd))
		{		
			MSGDATA msgData ;
			msgData.wParam = wParam;
			msgData.lParam = lParam;
			return ::SendMessage(m_hWnd,Msg,m_dwData,(LPARAM)&msgData);	
		}else
		{
			return TRUE;
		}
	}

	bool IsAsync(){return false;}

	void OnStart(E_TRAN_TYPE eType,DWORD length)
	{
		SendMessage(HTTP_SYNC_START,eType,length);
	}
	void OnRequestProgress(ULONG ulProgress,ULONG ulProgressMax)
	{
		SendMessage(HTTP_SYNC_REQUEST_PROCESS,ulProgress,ulProgressMax);
	}
	void OnResponseProgress(ULONG ulProgress,ULONG ulProgressMax)
	{
		SendMessage(HTTP_SYNC_RESPONSE_PROCESS,ulProgress,ulProgressMax);
	}

	void OnNotify(DWORD dwErr,DWORD dwInfo)
	{
		SendMessage(HTTP_SYNC_NOTIFY,dwErr,dwInfo);
	}
	void OnAbort()
	{
		SendMessage(HTTP_SYNC_ABORT,0,0);
	}
	void OnFinished(PCHAR ResponseText,DWORD dwSize)
	{
		SendMessage(HTTP_SYNC_FINISHED,(WPARAM)ResponseText,dwSize);
	}
	void OnCloseConnect()
	{
		SendMessage(HTTP_SYNC_CLOSECONNECT,0,0);
	}
protected:
	HWND m_hWnd;
	DWORD m_dwData;
};


//�첽���صĴ�����Ϣ�ص�
class WinMsgQueueAsync : public IHttpCallback
{
public:
	void InitCallback(HWND hWnd,DWORD dwID)
	{
		m_hWnd=hWnd;
		m_dwData=dwID;
	}

protected:
	BOOL PostMessage(__in UINT Msg,__in WPARAM wParam,__in LPARAM lParam)
	{
		if(m_hWnd)
		{		
			MSGDATA *msgData = new MSGDATA;
			msgData->wParam = wParam;
			msgData->lParam = lParam;
			BOOL bRet = ::PostMessage(m_hWnd,Msg,m_dwData,(LPARAM)msgData);	
			if (bRet == FALSE)
			{
				delete msgData;
			}

			return bRet;
		}else
		{
			return FALSE;
		}
	}

	bool IsAsync(){return true;}

	void OnStart(E_TRAN_TYPE eType,DWORD length)
	{
		PostMessage(HTTP_ASYNC_START,eType,length);
	}
	void OnRequestProgress(ULONG ulProgress,ULONG ulProgressMax)
	{
		PostMessage(HTTP_ASYNC_REQUEST_PROCESS,ulProgress,ulProgressMax);
	}
	void OnResponseProgress(ULONG ulProgress,ULONG ulProgressMax)
	{
		PostMessage(HTTP_ASYNC_RESPONSE_PROCESS,ulProgress,ulProgressMax);
	}

	void OnNotify(DWORD dwErr,DWORD dwInfo)
	{
		PostMessage(HTTP_ASYNC_NOTIFY,dwErr,dwInfo);
	}
	void OnAbort()
	{
		PostMessage(HTTP_ASYNC_ABORT,0,0);
	}
	void OnFinished(PCHAR ResponseText,DWORD dwSize)
	{
		if(ResponseText != NULL)
		{
			CHAR *p = new CHAR[dwSize];
			memcpy(p,ResponseText,dwSize);
			BOOL bRet = PostMessage(HTTP_ASYNC_FINISHED,(WPARAM)p,dwSize);
			if(bRet == FALSE)
				delete []p;
		}
		else
			PostMessage(HTTP_ASYNC_FINISHED,0,0);
	}
	void OnCloseConnect()
	{
		PostMessage(HTTP_ASYNC_CLOSECONNECT,0,0);
	}
protected:
	HWND m_hWnd;
	DWORD m_dwData;
};




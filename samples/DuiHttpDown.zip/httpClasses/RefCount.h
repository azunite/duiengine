#pragma once

/*
�̰߳�ȫ������
*/

#define DISALLOW_COPY_AND_ASSIGN(TypeName) \
	TypeName(const TypeName&);               \
	void operator=(const TypeName&)



template<class T>
class RefCountedThreadSafe
{
private:
	long ref_count_;
public:
	RefCountedThreadSafe(void):ref_count_(0){;}
	virtual ~RefCountedThreadSafe(void){;}
	void AddRef() {
		InterlockedIncrement(&ref_count_);
	}

	void Release() {
		if (InterlockedDecrement(&ref_count_) == 0) 
		{		
			delete static_cast<T*>(this);
		}
	}
	DISALLOW_COPY_AND_ASSIGN(RefCountedThreadSafe<T>);
};

template <class T>
class scoped_refptr {
public:
	scoped_refptr() : ptr_(NULL) {
	}

	scoped_refptr(T* p) : ptr_(p) {
		if (ptr_)
			ptr_->AddRef();
	}

	scoped_refptr(const scoped_refptr<T>& r) : ptr_(r.ptr_) {
		if (ptr_)
			ptr_->AddRef();
	}

	virtual ~scoped_refptr() {
		if (ptr_)
			ptr_->Release();
	}

	T* get() const { return ptr_; }
	operator T*() const { return ptr_; }
	T* operator->() const { return ptr_; }

	scoped_refptr<T>& operator=(T* p) {
		// AddRef first so that self assignment should work
		if (p)
			p->AddRef();
		if (ptr_ )
			ptr_ ->Release();
		ptr_ = p;
		return *this;
	}

	scoped_refptr<T>& operator=(const scoped_refptr<T>& r) {
		return *this = r.ptr_;
	}

	void swap(T** pp) {
		T* p = ptr_;
		ptr_ = *pp;
		*pp = p;
	}

	void swap(scoped_refptr<T>& r) {
		swap(&r.ptr_);
	}

private:
	T* ptr_;
};

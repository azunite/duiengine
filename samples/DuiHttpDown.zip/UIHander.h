#pragma once

#include "httpClasses/HttpCallBackImp.h"

class CMainDlg;

class CUIHander
{
public:
	CUIHander(CMainDlg *pMainDlg);
	~CUIHander(void);

protected:
	LRESULT OnInitDialog(HWND hWnd, LPARAM lParam);

	void OnBtnDownClick();
	LRESULT OnHttpFinish(WPARAM wp,LPARAM lp,DWORD dwID);
	LRESULT OnHttpProg(WPARAM wp,LPARAM lp,DWORD dwID);

	BEGIN_MSG_MAP_EX(CUIHander)
		MSG_DUI_NOTIFY(IDC_RICHVIEW_WIN)
		MSG_WM_INITDIALOG(OnInitDialog)
		MSG_HTTP_ASYNC_HANDLER(HTTP_ASYNC_RESPONSE_PROCESS,OnHttpProg)
		MSG_HTTP_ASYNC_HANDLER(HTTP_ASYNC_FINISHED,OnHttpFinish)
		MSG_HTTP_ASYNC_DEFAULT()
	END_MSG_MAP()

	DUI_NOTIFY_MAP(IDC_RICHVIEW_WIN)
		DUI_NOTIFY_ID_COMMAND(btn_down, OnBtnDownClick)
	DUI_NOTIFY_MAP_END()	
private:
	CMainDlg * m_pMainDlg; 
};

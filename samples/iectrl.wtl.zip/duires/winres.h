#pragma once

/*<---------------------------RES_BUILDER:begin-----------------------------------*/
#define	maindlg		65537
#define	btn_close		1
#define	IDC_IECTRL		65538
/*----------------------------RES_BUILDER:end------------------------------------->*/

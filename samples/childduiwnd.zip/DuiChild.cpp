#include "StdAfx.h"
#include "DuiChild.h"

CDuiChild::CDuiChild(void):CDuiHostWnd(IDR_DUI_CHILD_DIALOG)
{
}

CDuiChild::~CDuiChild(void)
{
}

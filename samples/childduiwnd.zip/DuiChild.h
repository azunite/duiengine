#pragma once

class CDuiChild :
	public CDuiHostWnd
{
public:
	CDuiChild(void);
	~CDuiChild(void);
};

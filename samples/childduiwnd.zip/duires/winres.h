#pragma once

/*<---------------------------RES_BUILDER:begin-----------------------------------*/
#define	maindlg		65537
#define	close		1
#define	IDC_DUICHILD		65538
#define	IDC_DELCHILD		65539
/*----------------------------RES_BUILDER:end------------------------------------->*/
